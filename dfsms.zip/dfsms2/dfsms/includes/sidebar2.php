        <nav class="hk-nav hk-nav-light">
            <a href="javascript:void(0);" id="hk_nav_close" class="hk-nav-close"><span class="feather-icon"><i data-feather="x"></i></span></a>
            <div class="nicescroll-bar">
                <div class="navbar-nav-wrap">
                    <ul class="navbar-nav flex-column">

<li class="nav-item">
<a class="nav-link" href="dashboard2.php">
<i class="ion ion-ios-keypad"></i>
<span class="nav-link-text">Dashboard</span>
</a>
</li>

                          







<li class="nav-item">
<a class="nav-link" href="search-product2.php">
<i class="glyphicon glyphicon-search"></i>
<span class="nav-link-text">Search Product</span>
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="invoices2.php">
<i class="ion ion-ios-list-box"></i>
<span class="nav-link-text">Invoices</span>
</a>
</li>



</ul>
                 
                      
                      
                      
                  
                
                    <hr class="nav-separator">
            
                </div>
            </div>
        </nav>